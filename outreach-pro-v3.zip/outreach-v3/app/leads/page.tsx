'use client'

import { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import {
  getLeads, addLeads, updateLead, deleteLead, clearLeads, getSettings,
  incrementTodaySent, getTodayStats,
} from '@/lib/storage'
import { CITY_COORDINATES, BUSINESS_CATEGORIES, JUDETE, HIGH_CONVERSION_CATEGORIES } from '@/lib/constants'
import type { Business, Settings } from '@/lib/types'

const CITIES = Object.keys(CITY_COORDINATES).sort()
const CATEGORIES = Object.entries(BUSINESS_CATEGORIES)

// ── Helpers ───────────────────────────────────────────────────────────────────
function Stars({ rating }: { rating: number }) {
  return (
    <span className="text-yellow-400 text-xs">
      {'★'.repeat(Math.round(rating))}{'☆'.repeat(5 - Math.round(rating))}
      <span className="text-slate-500 ml-1">{rating.toFixed(1)}</span>
    </span>
  )
}

function Badge({ status }: { status: Business['status'] }) {
  const map = {
    found:  { label: 'Găsit',  cls: 'badge-blue' },
    ready:  { label: 'Gata',   cls: 'badge-gold' },
    sent:   { label: 'Trimis', cls: 'badge-green' },
    failed: { label: 'Eroare', cls: 'badge-red' },
  }
  const s = map[status] || map.found
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${s.cls}`}>
      {s.label}
    </span>
  )
}

// ── Quick-send: generates + opens WhatsApp in one click ───────────────────────
function QuickSendButton({
  business, settings, onUpdate,
}: {
  business: Business; settings: Settings; onUpdate: (b: Business) => void
}) {
  const [state, setState] = useState<'idle' | 'generating' | 'ready' | 'sent'>('idle')
  const [msg, setMsg]     = useState(business.generated_whatsapp || '')
  const [err, setErr]     = useState('')

  useEffect(() => {
    if (business.generated_whatsapp) { setMsg(business.generated_whatsapp); setState('ready') }
    if (business.status === 'sent') setState('sent')
  }, [business])

  async function handleClick() {
    if (state === 'sent') return

    // If message ready, open WhatsApp immediately
    if (state === 'ready' && msg) {
      const url = business.whatsapp_link
        ? `${business.whatsapp_link}?text=${encodeURIComponent(msg)}`
        : `https://wa.me/?text=${encodeURIComponent(msg)}`
      window.open(url, '_blank')
      try { await navigator.clipboard.writeText(msg) } catch {}
      updateLead(business.place_id, { status: 'sent', sent_at: new Date().toISOString(), contact_method: 'whatsapp' })
      incrementTodaySent(true)
      onUpdate({ ...business, status: 'sent', contact_method: 'whatsapp' })
      setState('sent')
      return
    }

    // Generate then send
    setState('generating')
    setErr('')
    try {
      const res = await fetch('/api/generate-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          business,
          mode: 'whatsapp',
          variant: Math.floor(Math.random() * 4),
          anthropicApiKey: settings.anthropicApiKey,
          senderName:   settings.senderName,
          yourPortfolio: settings.yourPortfolio,
          yourPhone:    settings.yourPhone,
          priceFrom:    settings.priceFrom,
          priceTo:      settings.priceTo,
          deliveryDays: settings.deliveryDays,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Eroare')
      const generated = data.whatsapp || ''
      setMsg(generated)
      updateLead(business.place_id, { generated_whatsapp: generated, status: 'ready' })
      onUpdate({ ...business, generated_whatsapp: generated, status: 'ready' })
      setState('ready')

      // Auto-open WhatsApp right away
      const url = business.whatsapp_link
        ? `${business.whatsapp_link}?text=${encodeURIComponent(generated)}`
        : `https://wa.me/?text=${encodeURIComponent(generated)}`
      window.open(url, '_blank')
      try { await navigator.clipboard.writeText(generated) } catch {}
      updateLead(business.place_id, { status: 'sent', sent_at: new Date().toISOString(), contact_method: 'whatsapp' })
      incrementTodaySent(true)
      onUpdate({ ...business, generated_whatsapp: generated, status: 'sent', contact_method: 'whatsapp' })
      setState('sent')
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : String(e))
      setState('idle')
    }
  }

  if (state === 'sent') {
    return (
      <div className="w-full py-2.5 rounded-xl text-xs font-semibold text-center badge-green">
        ✅ Trimis pe WhatsApp
      </div>
    )
  }

  return (
    <>
      <button
        onClick={handleClick}
        disabled={!business.whatsapp_link || !settings.anthropicApiKey}
        className="w-full py-2.5 rounded-xl text-sm font-bold text-white transition-all btn-wa disabled:opacity-40"
      >
        {state === 'generating' ? '⏳ Generez mesaj...' :
         state === 'ready'      ? '📱 Trimite pe WhatsApp →' :
                                  '⚡ Generează & Trimite WA'}
      </button>
      {err && <p className="text-red-400 text-xs mt-1 text-center">{err}</p>}
      {!settings.anthropicApiKey && (
        <p className="text-amber-400 text-xs mt-1 text-center">Setează Anthropic API key în Setări</p>
      )}
    </>
  )
}

// ── Full message modal ────────────────────────────────────────────────────────
function MessageModal({
  business, settings, onClose, onSent,
}: {
  business: Business; settings: Settings; onClose: () => void; onSent: (b: Business) => void
}) {
  const [tab, setTab]         = useState<'whatsapp' | 'email'>(business.whatsapp_link ? 'whatsapp' : 'email')
  const [waMsg, setWaMsg]     = useState(business.generated_whatsapp || '')
  const [subject, setSubject] = useState(business.generated_subject || '')
  const [body, setBody]       = useState(business.generated_body || '')
  const [emailTo, setEmailTo] = useState(business.contact_email || '')
  const [generating, setGenerating] = useState(false)
  const [sending, setSending]       = useState(false)
  const [copied, setCopied]         = useState(false)
  const [error, setError]           = useState('')

  const needsWA    = !waMsg
  const needsEmail = !subject || !body

  async function generate(mode: 'whatsapp' | 'email' | 'both') {
    setGenerating(true); setError('')
    try {
      const res = await fetch('/api/generate-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          business, mode, variant: Math.floor(Math.random() * 4),
          anthropicApiKey: settings.anthropicApiKey,
          senderName: settings.senderName, yourWebsite: settings.yourWebsite,
          yourPortfolio: settings.yourPortfolio, yourPhone: settings.yourPhone,
          priceFrom: settings.priceFrom, priceTo: settings.priceTo, deliveryDays: settings.deliveryDays,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Eroare')
      if (data.whatsapp) setWaMsg(data.whatsapp)
      if (data.subject) setSubject(data.subject)
      if (data.body) setBody(data.body)
      updateLead(business.place_id, {
        generated_whatsapp: data.whatsapp || waMsg,
        generated_subject: data.subject || subject,
        generated_body: data.body || body,
        status: 'ready',
      })
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e))
    } finally { setGenerating(false) }
  }

  async function sendWhatsApp() {
    if (!waMsg) return
    try { await navigator.clipboard.writeText(waMsg); setCopied(true); setTimeout(() => setCopied(false), 3000) } catch {}
    const url = business.whatsapp_link
      ? `${business.whatsapp_link}?text=${encodeURIComponent(waMsg)}`
      : `https://wa.me/?text=${encodeURIComponent(waMsg)}`
    window.open(url, '_blank')
    updateLead(business.place_id, { status: 'sent', sent_at: new Date().toISOString(), contact_method: 'whatsapp' })
    incrementTodaySent(true)
    onSent({ ...business, status: 'sent', contact_method: 'whatsapp' })
    onClose()
  }

  async function sendEmail() {
    if (!emailTo || !subject || !body) return
    setSending(true)
    try {
      const res = await fetch('/api/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: emailTo, subject, emailBody: body,
          senderEmail: settings.senderEmail, senderAppPassword: settings.senderAppPassword, senderName: settings.senderName,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      updateLead(business.place_id, { status: 'sent', sent_at: new Date().toISOString(), contact_method: 'email' })
      incrementTodaySent(true)
      onSent({ ...business, status: 'sent', contact_method: 'email' })
      onClose()
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : String(e))
      incrementTodaySent(false)
    } finally { setSending(false) }
  }

  const inputStyle = { background: 'rgba(6,12,24,0.9)', border: '1px solid rgba(255,255,255,0.1)', outline: 'none' }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(6px)' }}>
      <div className="glass rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-in" style={{ border: '1px solid rgba(96,165,250,0.2)' }}>
        {/* Header */}
        <div className="p-6 border-b border-white/5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-display font-bold text-white text-lg">{business.name}</h3>
              <p className="text-slate-400 text-sm">{business.category_label} · {business.city}</p>
              <div className="flex items-center gap-3 mt-2 flex-wrap">
                <span className="text-slate-300 text-sm font-medium">📞 {business.phone}</span>
                {business.rating > 0 && <Stars rating={business.rating} />}
                {business.reviews_count > 0 && <span className="text-slate-500 text-xs">({business.reviews_count} recenzii)</span>}
                {business.is_small_city && <span className="text-xs px-2 py-0.5 rounded-full badge-gold">🏘️ Oraș mic</span>}
                {(business as any).has_website && <span className="text-xs px-2 py-0.5 rounded-full badge-blue">🌐 Are site</span>}
              </div>
            </div>
            <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors text-xl font-bold">✕</button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-4 pb-0">
          {(['whatsapp', 'email'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className="flex-1 py-3 rounded-xl text-sm font-bold transition-all"
              style={tab === t
                ? t === 'whatsapp'
                  ? { background: 'linear-gradient(135deg,#25D366,#128C7E)', color: '#fff', boxShadow: '0 4px 16px rgba(37,211,102,0.3)' }
                  : { background: 'linear-gradient(135deg,#60a5fa,#3b82f6)', color: '#fff', boxShadow: '0 4px 16px rgba(96,165,250,0.3)' }
                : { background: 'rgba(255,255,255,0.04)', color: '#64748b' }}>
              {t === 'whatsapp' ? '📱 WhatsApp' : '✉️ Email'}
            </button>
          ))}
        </div>

        <div className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl text-sm badge-red">⚠️ {error}</div>
          )}

          {/* WHATSAPP */}
          {tab === 'whatsapp' && (
            <div className="space-y-4">
              {!business.whatsapp_link && (
                <div className="p-3 rounded-xl text-sm text-center badge-gold">
                  ⚠️ Nu există număr valid. Încearcă tab-ul Email.
                </div>
              )}
              {needsWA ? (
                <div className="text-center py-10">
                  <p className="text-slate-400 text-sm mb-6">Generează mesaj WhatsApp personalizat cu AI</p>
                  <button onClick={() => generate('whatsapp')} disabled={generating || !settings.anthropicApiKey}
                    className="px-8 py-3.5 rounded-xl font-bold text-white btn-wa disabled:opacity-40">
                    {generating ? '⏳ Generez...' : '🤖 Generează mesaj'}
                  </button>
                  {!settings.anthropicApiKey && <p className="text-amber-400 text-xs mt-3">Configurează Anthropic API key în Setări</p>}
                </div>
              ) : (
                <>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Mesaj WhatsApp</label>
                      <button onClick={() => generate('whatsapp')} disabled={generating}
                        className="text-xs px-3 py-1 rounded-lg badge-wa disabled:opacity-50 font-semibold">
                        {generating ? '⏳' : '🔄 Regenerează'}
                      </button>
                    </div>
                    <textarea value={waMsg} onChange={e => setWaMsg(e.target.value)} rows={9}
                      className="w-full rounded-xl p-4 text-sm text-white resize-none leading-relaxed"
                      style={inputStyle} />
                    <p className="text-xs text-slate-600 mt-1">{waMsg.length} caractere · {waMsg.split('\n').length} rânduri</p>
                  </div>
                  <button onClick={sendWhatsApp} disabled={!business.whatsapp_link}
                    className="w-full py-4 rounded-2xl font-display font-bold text-white text-lg btn-wa disabled:opacity-40">
                    {copied ? '✅ Copiat! WhatsApp se deschide...' : '📱 Trimite pe WhatsApp →'}
                  </button>
                  <p className="text-xs text-slate-600 text-center">
                    Mesajul e pre-completat în WhatsApp – dai doar Send
                  </p>
                </>
              )}
            </div>
          )}

          {/* EMAIL */}
          {tab === 'email' && (
            <div className="space-y-4">
              {needsEmail ? (
                <div className="text-center py-10">
                  <p className="text-slate-400 text-sm mb-6">Generează email personalizat cu AI</p>
                  <button onClick={() => generate('email')} disabled={generating || !settings.anthropicApiKey}
                    className="px-8 py-3.5 rounded-xl font-bold text-white btn-blue disabled:opacity-40">
                    {generating ? '⏳ Generez...' : '🤖 Generează email'}
                  </button>
                </div>
              ) : (
                <>
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 block">Email destinatar</label>
                    <input value={emailTo} onChange={e => setEmailTo(e.target.value)}
                      placeholder="office@afacere.ro"
                      className="w-full rounded-xl px-4 py-3 text-sm" style={inputStyle} />
                    {!(business as any).has_website && (
                      <p className="text-xs text-slate-500 mt-1">Caută emailul pe Facebook sau LinkedIn al afacerii</p>
                    )}
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Subiect</label>
                      <button onClick={() => generate('email')} disabled={generating}
                        className="text-xs px-3 py-1 rounded-lg badge-blue disabled:opacity-50 font-semibold">
                        {generating ? '⏳' : '🔄 Regenerează'}
                      </button>
                    </div>
                    <input value={subject} onChange={e => setSubject(e.target.value)}
                      className="w-full rounded-xl px-4 py-3 text-sm" style={inputStyle} />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 block">Corp email</label>
                    <textarea value={body} onChange={e => setBody(e.target.value)} rows={11}
                      className="w-full rounded-xl p-4 text-sm text-white resize-none leading-relaxed"
                      style={inputStyle} />
                  </div>
                  <button onClick={sendEmail}
                    disabled={sending || !emailTo || !subject || !body || !settings.senderEmail}
                    className="w-full py-4 rounded-2xl font-display font-bold text-white text-lg btn-blue disabled:opacity-40">
                    {sending ? '⏳ Trimit...' : '✉️ Trimite Email →'}
                  </button>
                  {!settings.senderEmail && <p className="text-amber-400 text-xs text-center">Configurează email în Setări</p>}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── Lead Card ─────────────────────────────────────────────────────────────────
function LeadCard({
  business, settings, onUpdate, onDelete,
}: {
  business: Business; settings: Settings; onUpdate: (b: Business) => void; onDelete: (id: string) => void
}) {
  const [showModal, setShowModal] = useState(false)

  const priority = business.is_small_city
    ? { border: '1px solid rgba(245,158,11,0.25)', bg: 'rgba(245,158,11,0.03)' }
    : business.rating >= 4.5 && business.reviews_count >= 20
    ? { border: '1px solid rgba(37,211,102,0.2)', bg: 'rgba(37,211,102,0.02)' }
    : { border: '1px solid rgba(255,255,255,0.06)', bg: 'transparent' }

  return (
    <>
      <div className="rounded-2xl p-5 transition-all hover:translate-y-[-1px] animate-in"
           style={{ background: `rgba(255,255,255,0.03) ${priority.bg}`, border: priority.border }}>
        {/* Top row */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-0.5">
              <span className="font-display font-bold text-white text-sm truncate">{business.name}</span>
              {business.is_small_city && <span className="text-xs">🏘️</span>}
              <Badge status={business.status} />
            </div>
            <p className="text-slate-500 text-xs">{business.category_label} · {business.city}</p>
          </div>
          <button onClick={() => onDelete(business.place_id)}
            className="text-slate-700 hover:text-red-400 transition-colors text-sm flex-shrink-0 mt-0.5">✕</button>
        </div>

        {/* Meta */}
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <span className="text-slate-300 text-xs font-medium">📞 {business.phone}</span>
          {business.rating > 0 && <Stars rating={business.rating} />}
          {business.whatsapp_link
            ? <span className="text-xs font-bold badge-wa px-2 py-0.5 rounded-full">✓ WhatsApp</span>
            : <span className="text-xs text-slate-600">No WA</span>
          }
          {(business as any).has_website && (
            <span className="text-xs badge-blue px-2 py-0.5 rounded-full">🌐 Site existent</span>
          )}
          {business.contact_email && (
            <span className="text-xs badge-blue px-2 py-0.5 rounded-full" title={business.contact_email}>✉️ Email găsit</span>
          )}
        </div>

        {/* Actions */}
        <div className="space-y-2">
          {/* Primary: Quick WhatsApp send */}
          {business.status !== 'sent' && business.whatsapp_link && (
            <QuickSendButton business={business} settings={settings} onUpdate={onUpdate} />
          )}

          {/* Secondary: Full modal */}
          <button onClick={() => setShowModal(true)}
            className="w-full py-2 rounded-xl text-xs font-semibold transition-all text-slate-400 hover:text-white"
            style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
            {business.status === 'sent'
              ? '👁️ Vezi mesajele trimise'
              : (business.contact_email ? '✉️ Trimite Email' : '✏️ Editează & trimite')}
          </button>
        </div>
      </div>

      {showModal && (
        <MessageModal
          business={business} settings={settings}
          onClose={() => setShowModal(false)}
          onSent={(u) => { onUpdate(u); setShowModal(false) }}
        />
      )}
    </>
  )
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function LeadsPage() {
  const [leads, setLeads]         = useState<Business[]>([])
  const [settings, setSettings]   = useState<Settings>({} as Settings)
  const [city, setCity]           = useState('Cluj-Napoca')
  const [category, setCategory]   = useState('beauty_salon')
  const [judet, setJudet]         = useState('')
  const [searching, setSearching] = useState(false)
  const [searchErr, setSearchErr] = useState('')
  const [searchMode, setSearchMode] = useState<'city' | 'judet'>('city')
  const [filter, setFilter]       = useState<'all' | 'found' | 'ready' | 'sent'>('all')
  const [todaySent, setTodaySent] = useState(0)
  const [genAll, setGenAll]       = useState(false)
  const [genProg, setGenProg]     = useState(0)

  useEffect(() => {
    setLeads(getLeads())
    setSettings(getSettings())
    setTodaySent(getTodayStats().sent)
  }, [])

  async function searchOne(c: string, cat: string): Promise<Business[]> {
    const res = await fetch('/api/find-businesses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ city: c, category: cat, googleApiKey: settings.googlePlacesApiKey }),
    })
    const data = await res.json()
    if (!res.ok) throw new Error(data.error || 'Eroare API')
    return data.businesses || []
  }

  async function handleSearch() {
    if (!settings.googlePlacesApiKey) { setSearchErr('Configurează Google Places API key în Setări'); return }
    setSearching(true); setSearchErr('')
    try {
      let all: Business[] = []
      if (searchMode === 'judet' && judet) {
        for (const c of (JUDETE[judet] || [])) {
          try { all = [...all, ...(await searchOne(c, category))] } catch {}
        }
      } else {
        all = await searchOne(city, category)
      }
      setLeads(addLeads(all))
    } catch (e: unknown) {
      setSearchErr(e instanceof Error ? e.message : String(e))
    } finally { setSearching(false) }
  }

  async function generateAll() {
    const targets = leads.filter(l => !l.generated_whatsapp && l.status !== 'sent')
    if (!targets.length) return
    setGenAll(true); setGenProg(0)
    for (let i = 0; i < targets.length; i++) {
      try {
        const res = await fetch('/api/generate-message', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            business: targets[i], mode: 'both', variant: i % 4,
            anthropicApiKey: settings.anthropicApiKey,
            senderName: settings.senderName, yourWebsite: settings.yourWebsite,
            yourPortfolio: settings.yourPortfolio, yourPhone: settings.yourPhone,
            priceFrom: settings.priceFrom, priceTo: settings.priceTo, deliveryDays: settings.deliveryDays,
          }),
        })
        const data = await res.json()
        if (res.ok) {
          updateLead(targets[i].place_id, {
            generated_whatsapp: data.whatsapp || '',
            generated_subject: data.subject || '',
            generated_body: data.body || '',
            status: 'ready',
          })
        }
      } catch {}
      setGenProg(i + 1)
      await new Promise(r => setTimeout(r, 700))
    }
    setLeads(getLeads())
    setGenAll(false)
  }

  function handleUpdate(updated: Business) {
    updateLead(updated.place_id, updated)
    setLeads(getLeads())
    setTodaySent(getTodayStats().sent)
  }

  function handleDelete(id: string) {
    deleteLead(id)
    setLeads(getLeads())
  }

  const filtered     = leads.filter(l => filter === 'all' || l.status === filter)
  const withWA       = leads.filter(l => l.whatsapp_link && l.status !== 'sent').length
  const notGenerated = leads.filter(l => !l.generated_whatsapp && l.status !== 'sent').length

  const inputStyle = { background: 'rgba(6,12,24,0.8)', border: '1px solid rgba(255,255,255,0.08)', outline: 'none' }

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(160deg, #060c18 0%, #0a1628 60%, #06101e 100%)' }}>
      {/* Header */}
      <header className="border-b border-white/5 px-6 py-4 sticky top-0 z-40"
              style={{ background: 'rgba(6,12,24,0.92)', backdropFilter: 'blur(16px)' }}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="text-slate-500 hover:text-white transition-colors text-sm">← Acasă</Link>
            <span className="text-slate-700">/</span>
            <span className="font-display font-bold text-white">Leads</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm">
              <span className="text-white font-bold">{todaySent}</span>
              <span className="text-slate-500"> trimise azi</span>
            </span>
            <span className="text-sm">
              <span className="text-white font-bold">{leads.length}</span>
              <span className="text-slate-500"> leads total</span>
            </span>
            {leads.length > 0 && (
              <button onClick={() => { if (confirm('Ștergi toate leads-urile?')) { clearLeads(); setLeads([]) } }}
                className="text-xs px-3 py-1.5 rounded-lg badge-red font-semibold">
                Șterge tot
              </button>
            )}
            <Link href="/settings"
              className="px-4 py-2 rounded-xl text-sm font-semibold badge-blue transition-all">
              ⚙️ Setări
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8 flex gap-8">
        {/* Sidebar */}
        <aside className="w-80 flex-shrink-0 space-y-4">
          {/* Search panel */}
          <div className="glass rounded-2xl p-5">
            <h2 className="font-display font-bold text-white mb-4">🔍 Caută leads</h2>

            {/* Mode toggle */}
            <div className="flex gap-1 mb-4 p-1 rounded-xl" style={{ background: 'rgba(0,0,0,0.4)' }}>
              {(['city', 'judet'] as const).map(m => (
                <button key={m} onClick={() => setSearchMode(m)}
                  className="flex-1 py-1.5 rounded-lg text-xs font-bold transition-all"
                  style={searchMode === m
                    ? { background: 'rgba(96,165,250,0.2)', color: '#60a5fa' }
                    : { color: '#475569' }}>
                  {m === 'city' ? '🏙️ Oraș' : '🗺️ Județ'}
                </button>
              ))}
            </div>

            {searchMode === 'city' ? (
              <div className="mb-3">
                <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Oraș</label>
                <select value={city} onChange={e => setCity(e.target.value)}
                  className="w-full rounded-xl px-3 py-2.5 text-sm" style={inputStyle}>
                  {CITIES.map(c => (
                    <option key={c} value={c}>{CITY_COORDINATES[c]?.isSmall ? '🏘️ ' : ''}{c}</option>
                  ))}
                </select>
              </div>
            ) : (
              <div className="mb-3">
                <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Județ (toate orașele)</label>
                <select value={judet} onChange={e => setJudet(e.target.value)}
                  className="w-full rounded-xl px-3 py-2.5 text-sm" style={inputStyle}>
                  <option value="">Selectează județ...</option>
                  {Object.keys(JUDETE).map(j => (
                    <option key={j} value={j}>{j} ({JUDETE[j].length} orașe)</option>
                  ))}
                </select>
              </div>
            )}

            <div className="mb-4">
              <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Categorie</label>
              <select value={category} onChange={e => setCategory(e.target.value)}
                className="w-full rounded-xl px-3 py-2.5 text-sm" style={inputStyle}>
                <optgroup label="⭐ Conversie maximă">
                  {HIGH_CONVERSION_CATEGORIES.map(c => (
                    <option key={c} value={c}>{BUSINESS_CATEGORIES[c]}</option>
                  ))}
                </optgroup>
                <optgroup label="Toate categoriile">
                  {CATEGORIES.filter(([k]) => !HIGH_CONVERSION_CATEGORIES.includes(k)).map(([k, v]) => (
                    <option key={k} value={k}>{v}</option>
                  ))}
                </optgroup>
              </select>
            </div>

            {searchErr && (
              <div className="mb-3 p-3 rounded-xl text-xs badge-red">⚠️ {searchErr}</div>
            )}

            <button onClick={handleSearch} disabled={searching || (searchMode === 'judet' && !judet)}
              className="w-full py-3 rounded-xl font-bold text-white btn-blue disabled:opacity-50">
              {searching ? '⏳ Caut...' : '🔍 Caută afaceri fără site'}
            </button>

            {searching && (
              <p className="text-xs text-slate-500 text-center mt-2">
                Se accesează Google Maps... poate dura 10-30 sec
              </p>
            )}
          </div>

          {/* Stats */}
          {leads.length > 0 && (
            <div className="glass rounded-2xl p-5 space-y-3">
              <h3 className="font-display font-semibold text-white text-sm">📊 Statistici</h3>
              {[
                { label: 'Total leads',      value: leads.length, color: 'var(--blue)' },
                { label: '📱 Cu WhatsApp',   value: leads.filter(l => l.whatsapp_link).length, color: 'var(--wa)' },
                { label: '✉️ Cu Email',      value: leads.filter(l => l.contact_email).length, color: 'var(--blue)' },
                { label: '⚡ Gata de trimis',value: leads.filter(l => l.status === 'ready').length, color: 'var(--gold)' },
                { label: '✅ Trimise',        value: leads.filter(l => l.status === 'sent').length, color: '#4ade80' },
                { label: '🏘️ Orașe mici',    value: leads.filter(l => l.is_small_city).length, color: 'var(--gold)' },
              ].map(s => (
                <div key={s.label} className="flex items-center justify-between">
                  <span className="text-slate-400 text-xs">{s.label}</span>
                  <span className="font-bold text-sm" style={{ color: s.color }}>{s.value}</span>
                </div>
              ))}
            </div>
          )}

          {/* Bulk generate */}
          {notGenerated > 0 && settings.anthropicApiKey && (
            <div className="glass rounded-2xl p-5">
              <h3 className="font-display font-semibold text-white text-sm mb-2">🤖 Generare în masă</h3>
              <p className="text-slate-500 text-xs mb-3">{notGenerated} leads fără mesaj generat</p>
              {genAll && (
                <div className="mb-3">
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Progres</span>
                    <span>{genProg}/{notGenerated}</span>
                  </div>
                  <div className="w-full rounded-full h-1.5" style={{ background: 'rgba(255,255,255,0.06)' }}>
                    <div className="h-1.5 rounded-full transition-all btn-wa"
                         style={{ width: `${(genProg / notGenerated) * 100}%` }} />
                  </div>
                </div>
              )}
              <button onClick={generateAll} disabled={genAll}
                className="w-full py-2.5 rounded-xl text-sm font-bold text-white transition-all badge-wa disabled:opacity-50">
                {genAll ? `⏳ ${genProg}/${notGenerated}...` : `⚡ Generează toate (${notGenerated})`}
              </button>
            </div>
          )}

          {/* Tips */}
          <div className="glass rounded-2xl p-5">
            <h3 className="font-display font-semibold text-white text-sm mb-3">💡 Tips pentru azi</h3>
            <div className="space-y-2 text-xs text-slate-400">
              <p>🏘️ <strong className="text-white">Orașe mici</strong> = concurență zero online</p>
              <p>📱 <strong className="text-white">50 mesaje/zi WA</strong> = 2-3 clienți/săptămână</p>
              <p>⭐ <strong className="text-white">Rating 4.5+</strong> = motivație maximă să cumpere</p>
              <p>🍰 <strong className="text-white">Brutărie/patiserie</strong> = comenzi Paști acum</p>
            </div>
          </div>
        </aside>

        {/* Main */}
        <main className="flex-1 min-w-0">
          {/* Filter bar */}
          {leads.length > 0 && (
            <div className="flex gap-2 mb-6 flex-wrap items-center">
              {([
                { key: 'all',   label: `Toate (${leads.length})` },
                { key: 'found', label: `Găsite (${leads.filter(l => l.status === 'found').length})` },
                { key: 'ready', label: `Gata (${leads.filter(l => l.status === 'ready').length})` },
                { key: 'sent',  label: `Trimise (${leads.filter(l => l.status === 'sent').length})` },
              ] as const).map(f => (
                <button key={f.key} onClick={() => setFilter(f.key)}
                  className="px-4 py-2 rounded-xl text-sm font-semibold transition-all"
                  style={filter === f.key
                    ? { background: 'rgba(96,165,250,0.15)', color: '#60a5fa', border: '1px solid rgba(96,165,250,0.3)' }
                    : { background: 'rgba(255,255,255,0.04)', color: '#475569', border: '1px solid rgba(255,255,255,0.06)' }}>
                  {f.label}
                </button>
              ))}
              {withWA > 0 && (
                <div className="ml-auto text-sm font-semibold badge-wa px-4 py-2 rounded-xl">
                  📱 {withWA} disponibile WhatsApp
                </div>
              )}
            </div>
          )}

          {/* Empty state */}
          {leads.length === 0 && (
            <div className="text-center py-28">
              <div className="text-7xl mb-6">🎯</div>
              <h3 className="font-display text-2xl font-bold text-white mb-3">Zero leads deocamdată</h3>
              <p className="text-slate-400 mb-8 max-w-md mx-auto">Selectează un oraș sau județ, categoria și apasă „Caută afaceri fără site"</p>
              <div className="glass rounded-2xl p-6 max-w-sm mx-auto text-left space-y-3">
                <p className="text-sm font-bold text-white">💡 Start rapid recomandat:</p>
                <p className="text-sm text-slate-400">🏘️ Mod: <strong className="text-white">Județ → Cluj</strong></p>
                <p className="text-sm text-slate-400">💄 Categorie: <strong className="text-white">Salon de Înfrumusețare</strong></p>
                <p className="text-sm text-slate-400">⚡ Rezultat așteptat: <strong className="text-white">15-40 leads în 30 sec</strong></p>
              </div>
            </div>
          )}

          {/* Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(b => (
              <LeadCard
                key={b.place_id}
                business={b}
                settings={settings}
                onUpdate={handleUpdate}
                onDelete={handleDelete}
              />
            ))}
          </div>
        </main>
      </div>
    </div>
  )
}
