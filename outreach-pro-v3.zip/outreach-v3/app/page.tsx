'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { getLeads, getAllStats } from '@/lib/storage'

export default function Home() {
  const [leads, setLeads] = useState(0)
  const [sent, setSent]   = useState(0)
  const [ready, setReady] = useState(0)

  useEffect(() => {
    const all = getLeads()
    setLeads(all.length)
    setReady(all.filter(l => l.status === 'ready').length)
    const stats = getAllStats()
    setSent(stats.reduce((s, d) => s + d.sent, 0))
  }, [])

  return (
    <div className="min-h-screen" style={{ background: 'linear-gradient(160deg, #060c18 0%, #0a1628 60%, #06101e 100%)' }}>
      {/* Subtle grid bg */}
      <div className="fixed inset-0 pointer-events-none"
           style={{ backgroundImage: 'linear-gradient(rgba(96,165,250,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(96,165,250,0.03) 1px, transparent 1px)', backgroundSize: '60px 60px' }} />

      {/* Header */}
      <header className="relative border-b border-white/5 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg btn-wa">
              🎯
            </div>
            <span className="font-display font-bold text-lg text-white">Outreach Pro</span>
            <span className="text-xs px-2 py-0.5 rounded-full badge-blue font-semibold">v3</span>
          </div>
          <nav className="flex gap-2">
            <Link href="/leads" className="px-4 py-2 rounded-xl text-sm font-medium text-slate-400 hover:text-white hover:bg-white/5 transition-all">
              Leads
            </Link>
            <Link href="/settings" className="px-4 py-2 rounded-xl text-sm font-medium text-slate-400 hover:text-white hover:bg-white/5 transition-all">
              Setări
            </Link>
          </nav>
        </div>
      </header>

      <main className="relative max-w-6xl mx-auto px-6 py-20">
        {/* Hero */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold mb-8 badge-wa">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            LIVE · România 2025 · Actualizat azi
          </div>

          <h1 className="font-display text-5xl md:text-6xl font-extrabold text-white mb-6 leading-[1.1]">
            Găsește afaceri fără site.<br />
            <span style={{ background: 'linear-gradient(135deg, #25D366, #60a5fa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              Trimite oferta. Încasează.
            </span>
          </h1>

          <p className="text-slate-400 text-xl max-w-2xl mx-auto mb-12 leading-relaxed">
            Google Maps → leads automat → mesaj WhatsApp personalizat cu AI → primul client <strong className="text-white">azi</strong>.
          </p>

          <Link href="/leads"
            className="inline-flex items-center gap-3 px-10 py-4 rounded-2xl text-white font-bold text-lg btn-wa pulse-wa">
            <span>🚀</span> Începe campania acum
          </Link>
        </div>

        {/* Stats */}
        {(leads > 0 || sent > 0) && (
          <div className="grid grid-cols-3 gap-4 mb-20">
            {[
              { label: 'Leads găsite', value: leads, icon: '🎯', color: 'var(--blue)' },
              { label: 'Gata de trimis', value: ready, icon: '⚡', color: 'var(--gold)' },
              { label: 'Mesaje trimise', value: sent, icon: '✅', color: 'var(--wa)' },
            ].map(s => (
              <div key={s.label} className="glass-card rounded-2xl p-6 text-center">
                <div className="text-3xl mb-2">{s.icon}</div>
                <div className="font-display text-4xl font-extrabold mb-1" style={{ color: s.color }}>{s.value}</div>
                <div className="text-sm text-slate-400">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        {/* How it works */}
        <div className="glass rounded-3xl p-10">
          <h2 className="font-display text-2xl font-bold text-white mb-10 text-center">Procesul în 4 pași</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { step: '01', icon: '🔍', title: 'Caută leads', desc: 'Selectezi județul sau orașul și categoria. Google Maps găsește toate afacerile fără site, cu număr de telefon.' },
              { step: '02', icon: '🤖', title: 'AI generează', desc: 'Claude AI scrie un mesaj WhatsApp ultra-personalizat pentru fiecare afacere. Rata de conversie maximizată.' },
              { step: '03', icon: '📱', title: 'Trimite pe WA', desc: 'Click pe buton – mesajul e pre-completat în WhatsApp. Trimiți în 5 secunde, fără copy-paste.' },
              { step: '04', icon: '💰', title: 'Încasezi', desc: 'Clientul răspunde, tu faci site-ul, încasezi 500–2000 RON per proiect. Prima plată posibil azi.' },
            ].map(s => (
              <div key={s.step} className="text-center">
                <div className="font-display text-xs font-bold text-slate-600 mb-3 tracking-widest">{s.step}</div>
                <div className="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center text-2xl glass-card">
                  {s.icon}
                </div>
                <div className="font-display font-bold text-white mb-2">{s.title}</div>
                <div className="text-xs text-slate-400 leading-relaxed">{s.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Tips */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { icon: '🏘️', title: 'Orașe mici = conversie maximă', desc: 'În Huedin, Gherla, Râșnov nu există concurență online. Ești primul – câștigă.' },
            { icon: '💄', title: 'Saloane + pensiuni = bani rapizi', desc: 'Aceste afaceri pierd bani zilnic fără site. Motivația de a cumpăra e maximă.' },
            { icon: '⚡', title: 'Trimite 50 mesaje/zi pe WA', desc: 'La 5% conversie = 2-3 clienți/săptămână = 1.000–4.500 RON/săptămână.' },
          ].map(t => (
            <div key={t.title} className="glass-card rounded-2xl p-6">
              <div className="text-2xl mb-3">{t.icon}</div>
              <div className="font-semibold text-white mb-2">{t.title}</div>
              <div className="text-sm text-slate-400">{t.desc}</div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
