import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { CATEGORY_PAIN_POINTS } from '@/lib/constants'
import type { Business } from '@/lib/types'

export const maxDuration = 30

export async function POST(req: NextRequest) {
  const body = await req.json()
  const {
    business,
    mode = 'both',
    variant = 0,
    anthropicApiKey: clientKey,
    senderName,
    yourWebsite,
    yourPortfolio,
    yourPhone,
    priceFrom = '500',
    priceTo = '1500',
    deliveryDays = '5',
  }: {
    business: Business
    mode?: string
    variant?: number
    anthropicApiKey?: string
    senderName?: string
    yourWebsite?: string
    yourPortfolio?: string
    yourPhone?: string
    priceFrom?: string
    priceTo?: string
    deliveryDays?: string
  } = body

  const apiKey = process.env.ANTHROPIC_API_KEY || clientKey
  if (!apiKey) {
    return NextResponse.json({ error: 'Lipsă Anthropic API key' }, { status: 400 })
  }

  const ctx     = CATEGORY_PAIN_POINTS[business.category] ?? CATEGORY_PAIN_POINTS['default']
  const name    = process.env.SENDER_NAME          || senderName    || 'Alexandru'
  const website = process.env.YOUR_WEBSITE         || yourWebsite   || ''
  const portfolio = process.env.YOUR_PORTFOLIO_URL || yourPortfolio || ''
  const phone   = process.env.YOUR_PHONE           || yourPhone     || ''
  const pFrom   = process.env.PRICE_FROM           || priceFrom
  const days    = process.env.DELIVERY_DAYS        || deliveryDays

  const ratingCtx =
    business.rating >= 4.5 && business.reviews_count >= 20
      ? `are ${business.reviews_count} recenzii cu nota ${business.rating}★ – una din cele mai apreciate afaceri din zonă`
      : business.rating >= 4.0 && business.reviews_count >= 10
      ? `are ${business.reviews_count} recenzii cu ${business.rating}★ pe Google`
      : business.reviews_count >= 5
      ? `are ${business.reviews_count} recenzii pe Google`
      : ''

  const smallCityCtx = business.is_small_city
    ? `În ${business.city} aproape nu există concurență online în domeniu – dacă au site acum, vor domina căutările locale luni de zile.`
    : ''

  const month = new Date().getMonth() + 1
  const seasonCtx =
    month >= 3 && month <= 5 ? 'Suntem în primăvară – sezon de vârf pentru comenzi și rezervări.' :
    month >= 6 && month <= 8 ? 'Suntem în vară – sezonul turistic e la maxim.' :
    month >= 9 && month <= 11 ? 'Toamna aduce comenzi pentru nunți și evenimente.' :
    'Vine Crăciunul – comenzile online explodează în decembrie.'

  const client = new Anthropic({ apiKey })
  const results: { subject?: string; body?: string; whatsapp?: string } = {}

  // ─── WhatsApp ultra-conversion ──────────────────────────────────────────────
  if (mode === 'whatsapp' || mode === 'both') {
    const hooks = [
      `Bună ziua! Am căutat "${business.category_label.toLowerCase()} ${business.city}" pe Google și am observat că`,
      `Salut! Am văzut că ${business.name} are recenzii bune pe Google, dar`,
      `Bună ziua, am observat că ${business.name} din ${business.city}`,
      `Salut! Căutam ${business.category_label.toLowerCase()} în ${business.city} și am dat de ${business.name} –`,
    ]
    const opening = hooks[variant % 4]

    const waPrompt = `Ești cel mai bun copywriter român pentru WhatsApp B2B. Scrie un mesaj care să primească răspuns pozitiv în cel puțin 40% din cazuri.

AFACEREA ȚINTĂ:
- Nume: ${business.name}
- Tip: ${business.category_label}
- Oraș: ${business.city}
- Rating: ${ratingCtx || 'fără date'}
- Context local: ${smallCityCtx || 'oraș normal'}
- Sezon: ${seasonCtx}

OFERTA NOASTRĂ:
- Site web profesional în ${days} zile
- Preț fix: ${pFrom} RON (domeniu .ro + hosting 1 an + SEO de bază INCLUSE)
- Garanție satisfacție sau bani înapoi
${portfolio ? `- Exemple lucrări: ${portfolio}` : ''}
${phone ? `- Contact: ${phone}` : ''}

ÎNCEPE CU EXACT: "${opening}"

STRUCTURA (5 rânduri MAX, fiecare sub 15 cuvinte):
1. ${opening} [completează cu ceva SPECIFIC despre lipsa site sau oportunitatea ratată]
2. Ce pierd zilnic concret (o cifră sau fapt)
3. Oferta în 1 propoziție cu prețul fix
4. Garanție sau dovadă socială scurtă
5. Întrebare simplă cu răspuns DA ușor (ex: "Pot trimite 3 exemple de site-uri similare?")

TACTICI PSIHOLOGICE:
${ratingCtx ? `- "Cu ${ratingCtx}, merită o prezență online pe măsura calității"` : ''}
${business.is_small_city ? `- "În ${business.city} nu are nimeni site în domeniu – avantaj enorm acum"` : ''}
- Preț fix = elimini anxietatea
- Garanție = elimini riscul
- Întrebare mică la final = DA ușor

REGULI:
- MAX 5 rânduri, fiecare scurt
- Ton uman, direct, nu bot
- FĂRĂ: "Stimate", "Vă contactez", "Sper că", bullet points
- MAX 2 emoji
- Semnează cu "${name}"
- Varianta ${variant + 1}/4

Returnează DOAR mesajul, fără explicații.`

    try {
      const msg = await client.messages.create({
        model: 'claude-sonnet-4-6',
        max_tokens: 400,
        messages: [{ role: 'user', content: waPrompt }],
      })
      results.whatsapp = msg.content[0].type === 'text' ? msg.content[0].text.trim() : ''
    } catch {
      results.whatsapp = `${opening} nu are încă un site web.\n\nÎn fiecare zi, clienții care caută pe Google merg la concurență. ${ctx.waHook}.\n\nSite profesional în ${days} zile, ${pFrom} RON fix – domeniu + hosting incluse. Garanție sau bani înapoi.${portfolio ? `\n\nExemple: ${portfolio}` : ''}\n\nPot să vă trimit 3 exemple de site-uri similare?\n${name}`
    }
  }

  // ─── Email ultra-conversion ─────────────────────────────────────────────────
  if (mode === 'email' || mode === 'both') {
    const emailPrompt = `Ești expert în copywriting cold email cu rata de conversie record pentru IMM-uri din România.
Scrie un email cu rată de răspuns pozitiv de 15%+ (media industriei e 2%).

DATE AFACERE:
- Nume: ${business.name}
- Tip: ${business.category_label}
- Oraș: ${business.city}
- Rating: ${ratingCtx || 'fără detalii'}
- Context local: ${smallCityCtx || ''}
- Sezon: ${seasonCtx}

DURERE: ${ctx.pain}
CÂȘTIG: ${ctx.gain}
STATISTICĂ: ${ctx.hook}
URGENȚĂ: ${ctx.urgency}

OFERTA:
- Site în ${days} zile, preț fix ${pFrom} RON (domeniu + hosting + SEO + suport 3 luni – TOT inclus)
- Garanție sau bani înapoi
${portfolio ? `- Portofoliu: ${portfolio}` : ''}
${website ? `- Site: ${website}` : ''}
${phone ? `- Tel: ${phone}` : ''}

SUBJECT (max 7 cuvinte, personalizat, intrigant, NU clickbait):
Opțiuni: "${business.name} apare pe Google?" / "Am găsit ceva pentru ${business.name}" / "Clienți noi pentru ${business.name}"

BODY (MAX 150 cuvinte, 4 paragrafe):
P1 HOOK (2 rânduri): Compliment SPECIFIC și real – recenzii, locație, activitate
P2 PROBLEMĂ (2 rânduri): Ce pierd zilnic + o cifră/statistică
P3 SOLUȚIE (3 rânduri): Ce faci, timp, preț fix, garanție + "Am lucrat cu afaceri similare din regiune"
P4 CTA (1 rând): "Răspundeți cu DA și vă trimit 3 exemple în 10 minute"

REGULI:
- Română corectă, ton prietenos-profesional
- "Dumneavoastră" consistent
- FĂRĂ: "Sper că sunteți bine", "Permiteți-mi", intro corporatist
- Semnătură: ${name}${website ? `\n${website}` : ''}${phone ? `\n${phone}` : ''}

Returnează EXACT JSON fără markdown:
{"subject": "...", "body": "..."}`

    try {
      const msg = await client.messages.create({
        model: 'claude-sonnet-4-6',
        max_tokens: 1024,
        messages: [{ role: 'user', content: emailPrompt }],
      })
      const raw = msg.content[0].type === 'text' ? msg.content[0].text.trim() : ''
      const cleaned = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim()
      const match = cleaned.match(/\{[\s\S]*\}/)
      if (match) {
        const parsed = JSON.parse(match[0])
        results.subject = parsed.subject
        results.body    = parsed.body
      }
    } catch {
      results.subject = `${business.name} – clienți noi din Google de mâine`
      results.body    = `Bună ziua,\n\nAm căutat "${business.category_label.toLowerCase()}" în ${business.city} și ${business.name} iese în evidență${ratingCtx ? ` – ${ratingCtx}` : ''}.\n\n${ctx.hook} Fără un site propriu, clienții care caută online merg la concurență indiferent cât de buni sunteți.\n\nFac site-uri profesionale în ${days} zile, preț fix ${pFrom} RON – domeniu, hosting și SEO de bază incluse. Garanție sau bani înapoi. Am lucrat cu afaceri similare din regiune.\n\nRăspundeți cu "DA" și vă trimit 3 exemple în 10 minute.\n\n${name}${website ? `\n${website}` : ''}${phone ? `\n${phone}` : ''}`
    }
  }

  return NextResponse.json(results)
}
